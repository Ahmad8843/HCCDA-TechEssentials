# HCCDA-TechEssential
This repos is about performing different task and labs about HCCDA Tech Essentials.
- Basic Knowledge of Huawei Eco system
- Deployment of Linux on Huawei
- Networks & Storage Service on Huawei Cloud
- Deploying an Enterprise Web
- Compute Service
