This is about Python labs that I performed.
